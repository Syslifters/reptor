from reptor.lib.plugins.ToolBase import ToolBase
from reptor.models.Note import NoteTemplate


class Xsstool(ToolBase):
    """
    Example Commands:
        printf "https://example.com/alert(1)\nhttps://example.com/q=alert(1)" | reptor xsstool --format
    """

    meta = {
        "author": "Aron",
        "name": "XssTool",
        "version": "0.1",
        "license": "MIT",
        "tags": [],
        "summary": "Demo plugin for tutorial at https://docs.sysreptor.com/cli/writing-plugins/tools/",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.notename = kwargs.get("notetitle") or "XSS Tool"
        self.note_icon = "🔥"
        if self.input_format == "raw":
            self.input_format = "plaintext"

    @classmethod
    def add_arguments(cls, parser, plugin_filepath=None):
        super().add_arguments(parser, plugin_filepath=plugin_filepath)
        input_format_group = cls.get_input_format_group(parser)
        input_format_group.add_argument(
            "-plaintext",
            "--plaintext",
            help="plaintext output format",
            action="store_const",
            dest="format",
            const="plaintext",
        )
        parser.add_argument(
            "-multi-notes",
            "--multi-notes",
            help="Uploads multiple notes (one per target)",
            action="store_true",
        )

    def parse_json(self):
        """This is called automatically if the user provices --format json
        For more infos look at the parent parse() method in ToolBase
        """
        super().parse_json()

    def parse_plaintext(self):
        self.parsed_input = self.raw_input.splitlines()

    def parse(self):
        super().parse()
        if self.input_format == "plaintext":
            self.parse_plaintext()

    def preprocess_for_template(self):
        return {"data": self.parsed_input}

    def create_notes(self) -> NoteTemplate:
        data = {t: [t] for t in self.parsed_input}
        main_note = NoteTemplate()
        main_note.title = self.notetitle
        main_note.icon_emoji = self.note_icon
        main_note.parent_notetitle = "Uploads"
        for url, target_list in data.items():
            ip_note = NoteTemplate()
            ip_note.title = url
            ip_note.checked = False  # Make note an unticked checkbox instead of emoji
            ip_note.template = "xss-list"  # Format note using the selected Django template
            ip_note.template_data = {"data": target_list}  # Provide data for template
            main_note.children.append(ip_note)  # Append as child of parent note
        return main_note

    def finding_xss(self):
        if len(self.parsed_input) > 0:
            result = self.preprocess_for_template()
            result["affected_components"] = self.parsed_input
            return result
        return None


loader = Xsstool
