**XSS targets**

<!--{% load md %}--><!--{% noemptylines %}-->
<!--{% for xss_target in data %}-->
* <!--{{xss_target}}-->
<!--{% endfor %}-->
<!--{% endnoemptylines %}-->